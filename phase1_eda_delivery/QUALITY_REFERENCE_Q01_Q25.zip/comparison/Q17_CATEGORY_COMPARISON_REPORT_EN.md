# Q17: Between-category numeric outlier diagnostics

This is a postprocessing comparison of per-category Q15 and Q16 reports; no raw data are rescanned.

Provided categories: Electronics, Beauty_and_Personal_Care, Appliances, All_Beauty
Missing categories: none

Each row preserves its own reference denominator, method, percentile, and category-specific threshold.

| Metric | Category | Screened | Flagged | % of screened | Screen status | Full input |
|---|---|---:|---:|---:|---|---|
| reviews.helpful_vote | Electronics | 43886940 | 186260 | 0.42441 | computed | True |
| metadata.price | Electronics | 526449 | 74822 | 14.21258 | computed | True |
| metadata.rating_number | Electronics | 1610012 | 138 | 0.00857 | computed | True |
| reviews.helpful_vote | Beauty_and_Personal_Care | 23911390 | 104206 | 0.4358 | computed | True |
| metadata.price | Beauty_and_Personal_Care | 380597 | 34920 | 9.17506 | computed | True |
| metadata.rating_number | Beauty_and_Personal_Care | 1028914 | 4 | 0.00039 | computed | True |
| reviews.helpful_vote | Appliances | 2128605 | 8164 | 0.38354 | computed | True |
| metadata.price | Appliances | 46726 | 5473 | 11.71296 | computed | True |
| metadata.rating_number | Appliances | 94327 | 0 | 0.0 | computed | True |
| reviews.helpful_vote | All_Beauty | 701528 | 1948 | 0.27768 | computed | True |
| metadata.price | All_Beauty | 17704 | 1341 | 7.57456 | computed | True |
| metadata.rating_number | All_Beauty | 112590 | 17 | 0.0151 | computed | True |

## Interpretation

- reviews.helpful_vote: descriptive_four_category_comparison; rate spread = 0.15812 percentage points.
- metadata.price: descriptive_four_category_comparison; rate spread = 6.63802 percentage points.
- metadata.rating_number: descriptive_four_category_comparison; rate spread = 0.0151 percentage points.

The Amazon download categories can share products/reviews. Category-level rates are descriptive; shared rows/products have NOT been deduplicated across category files. Do not apply independent-sample tests or make causal claims.

Each category keeps its OWN full-file threshold from Q15/Q16. Comparing outlier rates does NOT mean the same numeric cutoff was used. Global/snapshot thresholds must not be reused for training-time preprocessing.

Only a complete full-file audit of all four categories supports a four-category description. Partial scans, samples and undefined fences are individually visible and block spread claims.

No raw files are modified. No new outliers are labeled in this step.
