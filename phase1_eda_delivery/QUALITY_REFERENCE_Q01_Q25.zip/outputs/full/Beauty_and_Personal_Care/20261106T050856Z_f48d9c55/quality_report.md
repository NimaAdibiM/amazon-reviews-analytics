# Diagnostic data quality audit

Scope: entire_supplied_dataset_files

Raw data is unchanged. No record is deleted or imputed; no prediction target is created.

## Input and parsing

### reviews

- Physical lines: 23,911,390
- Accepted unambiguous JSON objects: 23,911,390
- Parse errors (including duplicate JSON keys and nonfinite numbers): 0
- Blank lines: 0; nonobject lines: 0
- Verified full-record duplicate extra rows: 242,473

### metadata

- Physical lines: 1,028,914
- Accepted unambiguous JSON objects: 1,028,914
- Parse errors (including duplicate JSON keys and nonfinite numbers): 0
- Blank lines: 0; nonobject lines: 0
- Verified full-record duplicate extra rows: 0

## Counts and initial decisions

| File | Rule | Affected rows | Initial decision |
|---|---|---:|---|
| reviews | full_record_duplicate_extra | 242,473 | Later retain one verified canonical copy and log the removed copies; do not count duplicates as separate reviews. Raw files remain unchanged. |
| reviews | text_control_character | 108 | Retain the review's position; keep a text-availability flag. Inspect unusual content without automatic deletion. |
| reviews | text_html_like_markup | 1,680,890 | Retain the review's position; keep a text-availability flag. Inspect unusual content without automatic deletion. |
| reviews | text_possible_missing_marker | 6,194 | Retain the review's position; keep a text-availability flag. Inspect unusual content without automatic deletion. |
| reviews | text_replacement_character | 9 | Retain the review's position; keep a text-availability flag. Inspect unusual content without automatic deletion. |
| reviews | text_very_long_heuristic | 184 | Retain the review's position; keep a text-availability flag. Inspect unusual content without automatic deletion. |
| reviews | text_very_short_heuristic | 2,391,940 | Retain the review's position; keep a text-availability flag. Inspect unusual content without automatic deletion. |
| reviews | title_control_character | 6 | Retain the review's position; keep a text-availability flag. Inspect unusual content without automatic deletion. |
| reviews | title_html_like_markup | 4 | Retain the review's position; keep a text-availability flag. Inspect unusual content without automatic deletion. |
| reviews | title_possible_missing_marker | 6,362 | Retain the review's position; keep a text-availability flag. Inspect unusual content without automatic deletion. |
| metadata | price_invalid | 83 | Keep missing/invalid price explicit; do not impute blindly. Current price is not a main historical feature. |
| metadata | price_wrong_type | 83 | Keep missing/invalid price explicit; do not impute blindly. Current price is not a main historical feature. |
| metadata | price_zero_requires_inspection | 18 | Keep missing/invalid price explicit; do not impute blindly. Current price is not a main historical feature. |
| metadata | store_possible_missing_marker | 1,270 | Inspect examples and document a later processing rule; no automatic repair or deletion in this step. |
| metadata | title_possible_missing_marker | 3 | Retain the review's position; keep a text-availability flag. Inspect unusual content without automatic deletion. |

## Missing fields (Q01)

missingness.csv reports the six exclusive raw states for each field. The sum of states is asserted to equal all parsed object records for that file. Neither numeric zero nor boolean False is missing. Suspicious sentinel words remain literal strings and are flagged separately.

q01_nested_content.csv separately reports field-specific *syntactic* content usability inside known nonempty nested fields. Its raw_nonempty_but_unusable_rows are a subset of present_nonempty, not a seventh missing state. Valid-looking media URLs are not downloaded; nonblank strings may still be semantically uninformative.

## Field missingness rates (Q02)

q02_field_missingness.csv reports one row for every expected or observed field in both review and metadata inputs. The denominator is the count of successfully parsed JSON objects in THAT FILE and THAT scan (not physical lines or valid-after-dedup rows). Original copies are counted; errors/blank/nonobjects remain in file-level diagnostics.

raw_missing = absent + null. raw_missing_or_empty = raw_missing + blank_string + empty_array + empty_object. These are two distinct definitions; neither includes nonempty content which may be wrong type or semantically unusable. No source records are modified. State percentages and both combined rates are given explicitly in 0-100 percent units; original missingness.csv shares remain 0-1.

A missing field across the entire file is still reported when documented in EXPECTED. If a scan has zero accepted objects, rates are undefined (null / blank in CSV), NOT zero percent. Scope (full supplied file, sample, or head preview) must be checked before interpreting a rate as a dataset property.

Missing text alone does not remove a review from the ordered sequence. Missing current price is retained explicitly; no blind imputation is used.

## Q03: effect of missing/invalid core fields on analysis readiness

q03_review_readiness.csv reports missing-or-empty and present-but-unusable values separately for parent_asin, rating and timestamp. Overlapping failures are counted exactly once in the union via mutually exclusive bit masks. The denominators are parsed raw review objects before exact deduplication; title and body text are OPTIONAL for review positions and are reported separately.
q03_product_impact.csv counts distinct products with an indexable raw parent_asin and compares product counts with at least the configured minimum of 15 raw reviews versus 15 core-usable reviews. This uses an on-disk SQLite aggregation and does not load all product identifiers into memory. Any product count of 15+ is a preliminary screening upper bound ONLY, not definitive 5+10 cohort membership. Deduplication, temporal tie-breaking, joins and splits are separate work. Missing current price, metadata and images never automatically remove a review from the main rating/time sequence.

## Q04: full-record exact duplicates in reviews

q04_review_exact_duplicates.csv distinguishes unique canonical records, groups with repeats, all rows in those groups, and extra copies beyond the first. Percentages use explicit compared/parsed review-object denominators, never product or user keys. q04_duplicate_example_lines.csv contains bounded physical-line pairs (first copy, first repeated copy), without exposing review text.
SHA-256 serves only as an index: any digest match is rechecked against the COMPLETE canonical JSON record from disk. Whitespace and object key order do not change parsed identity; array order and int/float types remain significant. Distinct canonical rows under a digest collision are counted separately. A canonicalization failure is counted as not compared, not assumed unique.
This result is only for the scanned input (head_preview is not an exhaustive audit). No duplicates are removed. Duplicate keys or malformed JSON are handled by parsing checks and excluded from the parsed-review denominator. Shared copies across different category files require a separate cross-file check. Same user/product/time or similar text are not automatically exact duplicates. Product eligibility in Q03 is still BEFORE deduplication.

## Q05: full-record exact duplicates in metadata

q05_metadata_exact_duplicates.csv gives the exact same verified canonical-JSON census for metadata objects, including unique records, duplicate groups, rows in groups, extra copies, rates with explicit parsed/compared denominators and collision diagnostics. q05_metadata_duplicate_example_lines.csv records bounded physical source-line pairs without metadata contents.
A repeated parent_asin is NOT automatically a duplicate metadata record: different records sharing one key must be handled in the separate Q06/S14 key-multiplicity audit before joining to reviews. Verified identical extra copies are only PROPOSED for later removal in a derived view, and source files are never altered. A preview/partial scan proves nothing about the entire dataset; between-category exact duplicates require a separate cross-file analysis.

## Q06: identifier multiplicity versus full-record duplicates

q06_identifier_multiplicity.csv counts exact RAW nonblank identifier keys separately from Q04/Q05 verified complete-record duplicates. Review parent_asin, asin and user_id are allowed to repeat; repeated keys alone never justify removing reviews. Percentages are of scanned parsed objects or key-bearing objects as labeled.
q06_metadata_parent_versions.csv splits repeated metadata parent_asin groups into exact-copy-only, verified different records (conflicting versions), and indeterminate when canonicalization could not be completed. Metadata with different records under the same parent key must NOT be arbitrarily joined; this is a diagnostic complement to structural S14, not a replacement for its join tests.
No raw IDs or text are exposed in these summary CSVs. No deduplication is performed. Cross-category overlaps are not covered. With head_preview only the scanned prefix is counted.

## Q07: review field type compatibility

q07_review_type_compatibility.csv profiles all documented and additionally observed REVIEW fields, including expected non-null types, observed raw JSON types, explicit-null/absent counts, compatible and incompatible non-null values, and mismatch percentages with both denominators. Numeric-looking string counts are optional conversion candidates only: they remain WRONG TYPE until a separate, justified transformation. No conversion is performed here.
Missing/null values are not type errors. Booleans are not integers. Extra fields are profiled but do not fail an unspecified schema. Wrong-type occurrences are per FIELD and may overlap on the same record: the total is not a distinct-record count. Zero-observation and null-only fields are preserved; their rates are undefined where the non-null denominator is zero. Q08 separately audits metadata field types. All Q01-Q06 outputs are retained.

## Q08: metadata top-level and nested field types

q08_metadata_type_compatibility.csv reports raw JSON type compatibility for all documented and observed METADATA fields, with explicit absent/null counts, denominators, and numeric-looking string candidates (not automatically converted). Integer-only rating_number is distinct from float-permitted price and average_rating. Domain validity is checked separately in Q14.
q08_metadata_nested_types.csv separately screens items in known string and media-object lists, and recognized string-valued image/video descriptor attributes. Child JSON nulls are counted separately and are NOT wrong non-null types. Nested percentages use CHILD OCCURRENCES, whereas affected-metadata-record percentages use the number of records containing a correctly typed parent container. Details object values are profiled without an invented fixed value schema; unknown nested media keys are not automatically errors.
No raw values, IDs or text are exported. These are screening assumptions for known fields, not claims that all source versions always use the same nested schema. No records are changed. Q01-Q07 outputs are preserved.

## Q09: lexical format and categorical spelling consistency

q09_format_flags.csv reports nonblank inspected strings, surrounding/repeated whitespace, ASIN uppercase-ten-character convention warnings, and normalized detail-key collisions. These are diagnostic candidates and NEVER validation failures or automated repairs. Review body and heterogeneous details values are excluded from case-based matching.
q09_category_variant_groups.csv reports distinct short, valid-Unicode category label SPELLINGS sharing an identical whitespace-collapsed/casefolded representation; main_category and categories[] are independent groups. Only category labels are casefolded for this screening. No identifiers or review contents are normalized, joined, removed or recoded. Raw category samples are included in this targeted, bounded example report to support manual inspection.
A 256-character cap applies ONLY to category-label variant grouping to bound disk use; all excluded labels are counted in q09_format_flags.csv. No guarantee that differently spelled category labels have the same meaning; even casefold matches need inspection. Counts can overlap; totals are not counts of bad records. Numeric-like strings and timestamps are already checked in Q07/Q08 and S17/Q13; the Amazon data do not supply a universal unit/currency normalization contract. No transformations occur.

## Q11: review-star rating domain and integer validity

q11_review_rating_validity.csv partitions every parsed review object into exactly one of five statuses: valid integral 1..5 (including 5.0), missing/empty, wrong nonnull type (including boolean), numeric outside [1,5], and fractional numeric within [1,5]. No automatic clipping, rounding or parsing of numeric-looking strings occurs. Numeric fractions outside [1,5] are counted as outside-range in the exclusive partition, but are also covered in a separately named overlapping fractional-all summary. Rates use parsed raw review objects, NOT physical lines or deduplicated records. All zero statuses and undefined empty-file rates are reported explicitly.
q11_review_star_distribution.csv reports valid 1..5 stars both as a proportion of all parsed reviews and of valid rated reviews. The existing A/Q03 valid_rating and rating_out_of_domain counts are independently cross-checked. This is a diagnostic and not a prediction-label construction. For invalid/missing ratings the raw review is retained; the record remains unusable for the core rating sequence until resolved. No source files are changed.

## Q12: review helpful_vote and verified_purchase domain checks

q12_review_value_validity.csv partitions EACH parsed review into one status for helpful_vote and one for verified_purchase. Helpful_vote must be a raw JSON nonnegative integer (not boolean or integral-looking float). Verified_purchase must be a raw JSON boolean; numeric 0/1 and strings are not coerced. Explicit null and absent/empty field values are reported as missing/empty and excluded from the valid count. Both fields use the same denominator of all parsed review objects, including raw duplicate copies but excluding malformed or nonobject lines.
q12_review_numeric_flags.csv provides descriptive overlapping diagnostics for float-valued helpful_vote, including negative and fractional candidates. These flags are NOT additional bad rows and must not be summed with exclusive invalid statuses. Original helpful_vote_invalid and Q07 wrong-type counts are cross-checked to detect regressions. A missing/invalid helpful_vote or verified_purchase is a field-level limitation, not evidence that the entire review should be removed or that rating/chronological position is invalid. No automatic repair, deletion or transformation is performed.

## Q13: review timestamp technical validity and plausibility

q13_review_timestamp_validity.csv partitions all parsed review objects into six mutually exclusive statuses: missing/empty; wrong nonempty type; unrepresentable integer; representable before release-window start; representable within window; and representable at/after window end. All statuses have explicit denominator and sample physical-line positions. Counts cross-check Q01, Q03, Q07 and original temporal flags. This is an audit of review creation timestamp, NOT metadata crawl time.
q13_timestamp_suspicions.csv separately reports a potentially overlapping warning for REPRESENTABLE timestamps later than the fixed as-of UTC time, and exact observed earliest/latest datetimes. Reference bounds are in the configured timestamp unit (seconds or milliseconds), shown both as numeric epochs and UTC dates. The documented dataset window is a plausibility reference, not evidence of an invalid observation. Technical representability does not guarantee a usable historical sequence, and Q03 original core counts remain unchanged; future timestamps require a downstream eligibility policy. Neither input nor timestamps are modified. For deterministic replication, set quality_settings.q13_audit_as_of_utc to a timezone-aware ISO timestamp.

## Q14: metadata price, average_rating and rating_number validity

q14_metadata_value_validity.csv partitions every parsed METADATA object into one exclusive status for each of price, average_rating and rating_number, with explicit denominators, example source lines and initial decisions. Price must be a JSON numeric >=0; zero is a plausible free-item/sentinel warning, not proof of error. Product average_rating values 1..5 are domain-valid, whereas zero is separately screened as a possible unrated source sentinel; original A treats zero as outside its adopted rating range and its legacy counters remain unchanged. Product rating_number must be a nonnegative raw JSON integer; negative, fractional and integral-looking floats are separated and never rounded or converted. Missing/empty and raw wrong types remain distinguishable.
q14_metadata_numeric_flags.csv contains explicitly overlapping metadata rating_number flags, which must not be added to the exclusive counts. The Q14 output cross-checks Q08 raw-type counts, Q10 snapshot context and original A domain rules, but it does not infer contradictions by equating rating_number to the count of downloaded reviews. Very high valid numeric values are examined further as statistical outliers in Q16. Current metadata aggregates and current price are NOT historically available predictors merely because the file contains them. Source files stay unchanged.

## Q10: within-record cross-field consistency candidates

q10_cross_field_consistency.csv partitions EACH parsed object into one outcome with explicit denominator, including zero-count outcomes and nonassessable cases. Review asin / parent_asin equality is purely descriptive: different valid IDs are not an error. Metadata zero/nonzero disagreement between rating_number and average_rating is a suspicious snapshot-aggregate candidate only, not a logically proven contradiction. Source-specific zero sentinel behavior and crawl timing must be checked before any decision. No invented hard rule for verified_purchase, helpful_vote, main_category/categories, or full-review-vs-metadata rating totals is imposed. No raw data is changed; no pair is inferred from separate unmatched records.

## Possible review-event groups

{"groups": 23668855, "repeated_groups": 207198, "groups_with_different_record_fingerprints": 62, "interpretation": "SHA-256 grouping of exact user_id, parent_asin and timestamp. Candidate events only, not proven duplicates; hashes do not resolve event identity."}

## Statistical outliers

Full scanned-data frequency tables define diagnostic quartiles and Tukey fences. No outlier is automatically deleted. With zero IQR the count is undefined, not zero: inspect the discrete/zero-inflated distribution. Short/long text thresholds are configurable heuristics, not proof of bad data.

## Q15: review numeric outliers (helpful votes)

q15_review_numeric_outliers.csv screens only domain-valid raw nonnegative integer helpful_vote counts. This is the meaningful free-ranging raw numeric review attribute; star ratings have a finite discrete domain (Q11), and timestamps are audited for temporal validity in Q13. Text lengths have their own dedicated text audit (Q22-Q23).
For zero-inflated counts, the optional upper-tail screen is based on positive counts only: log1p transform, frequency-weighted Q1/Q3, upper fence Q3+3*IQR, and strictly-above-fence positive observations. Positive-only is a statistical reference subset, NOT removal of zero-vote reviews. Report both the screened-all denominator and the positive-only denominator explicitly. If there are fewer than four positive values or the positive-log IQR is zero, the statistical outlier count is UNDEFINED, never zero.
The existing numeric_outliers.csv stays unchanged as a descriptive raw-scale 1.5-IQR baseline. The new 95th/99th percentiles refer to ALL screened valid vote counts, with a separate strict >p99 descriptive tail count. Domain-invalid votes and valid integers above 2**53 are excluded from the floating-point reference and documented through Q12 and explicit omission counts. No record is removed, no imputation occurs, and a high vote count is not an impossible value. Thresholds derived here must not be reused as fitted predictors before a leakage-safe split.

## Q16: metadata numeric outliers (price and rating counts)

q16_metadata_numeric_outliers.csv reports exactly two independent distributions: metadata.price and metadata.rating_number. Both first use Q14-validated values; invalid, missing and raw type-mismatched values are not silently coerced. Valid raw integer values above 2**53 are reported as excluded from floating-point diagnostic summaries, not ignored. Reference denominator is parsed metadata objects; screened and positive-only denominators are stated separately.
For price, the primary descriptive screen is the original two-sided raw-scale Tukey 1.5*IQR rule, with positive-only log1p 3*IQR as a sensitivity analysis. For nonnegative integer rating counts, the primary descriptive screen uses only positive values to form a log1p upper 3*IQR reference and also reports the raw-scale baseline. Zero values remain in the census; a zero price is a warning from Q14, not missingness or a proven error.
The 95th and 99th percentiles and strictly-above-p99 counts are for ALL screened values. If either reference has fewer than four values, zero IQR or unusable fences, its outlier count is undefined (null), not zero. The entire available file forms this provisional distribution; category-specific comparisons are Q17 and cannot be inferred from this single-file screen. No values or records are changed, and metadata snapshot fields must not be used to predict historical reviews without leakage checks.

## Q18: separate data errors and statistical extremes

q18_outlier_vs_invalid.csv combines prior validation (Q11, Q12, Q13, Q14) and statistical screening (Q15, Q16). Each field is partitioned into mutually exclusive missing, wrong-type, domain/technical-invalid, accepted, and source-warning statuses. The exclusive categories sum exactly to parsed objects. Some warnings are technically usable (zero price and representable timestamps outside a plausibility window); a zero product average is an unresolved sentinel warning and remains unusable under Q14's adopted baseline.
A statistically flagged outlier is already an accepted field value: NEVER add it to missing/invalid counts. Screening is not applied to bounded star ratings, average_rating or timestamp. Null statistical flags mean no defensible fence was computed; they do NOT mean zero outliers. Very large integers deliberately omitted from float-based diagnostics remain valid where Q12/Q14 accept them. Domain-usability is a FIELD-level classification, not permission to use historical metadata as predictive features and not a count of eligible 5+10 products.

## Limits

- Rule counts can overlap; their sum is not a count of unique bad records.
- Duplicate counts compare complete canonical JSON records after strict parsing; formatting and object key order are ignored, array order and numeric type representation are preserved.
- Possible event groups use user/product/time, but are not asserted to be one real review event. No event versions are resolved in this step.
- Availability of an HTTP image URL does not prove that a downloadable image exists. No images or URLs are fetched.
- Modality rates have within-file denominators. Cross-file product joins and missingness mechanisms require later analysis; absence cannot be declared random here.
- Timestamp units are configured explicitly. Coverage flags are suspicions for follow-up, not proof of invalid dates.
- Numeric-string values are reported as type mismatches, not silently converted.
- Global quartiles are descriptive only; do not reuse them as fitted preprocessing thresholds for model evaluation.

## Q20 — exact within-row overlaps among defined audit families
q20_issue_families.csv contains nonexclusive family counts; q20_issue_pairs.csv contains exact pair intersections; q20_issue_signatures.csv partitions each parsed object into one exact bitmask; q20_issue_union.csv gives exact broad and narrower unions. Counts overlap among eight explicitly defined families of parsed JSON object records BEFORE dedup. Absent/null EXPECTED fields (including optional metadata) are descriptive missingness, NOT a proof of unusability. Formatting and source warnings are provisional; union(any family) must NOT be called erroneous rows. Q06 repeated identifiers and post-scan Q15/Q16 statistical outlier memberships are NOT in this union. No claim is made about the union of ALL possible quality issues; review core readiness remains Q03.


## Q19: rate denominators and arithmetic reconciliation

q19_rate_denominator_ledger.csv gives each rate its numerator, denominator, denominator unit, original rate, recomputed rate, scope, and relation (exclusive, subset, or overlapping). Every rate-bearing column in the registered Q01-Q18 CSV outputs has an explicit contract; missing contracts, mismatched rates, invalid count totals, and incorrect parsed-object denominators stop the audit. Shares are in [0,1] while percentages are in [0,100]. Undefined rates remain blank, never zero. Non-object, malformed and blank physical lines are counted in a separate physical-line census.
q19_rate_integrity.json gives the reconciliation totals and limitations. No raw records are revisited and no Q01-Q18 output is changed.

## Q22 — review body-text length distributions
q22_text_presence.csv partitions parsed review objects into absent, null, blank-string, nonblank-string, and wrong-type body fields. q22_text_length_distribution.csv gives Unicode code-point and whitespace-separated word counts with six weighted quantiles, minimum, maximum, and mean. q22_text_length_buckets.csv contains fixed, exhaustive and disjoint bins. Percentages use explicit string or all-parsed-review denominators and are checked by Q19. Length zero means a present empty string; no length is assigned to missing or nonstring values. Distributions count all raw parsed review objects before dedup, including repeated copies. This audit does not select 5+10 cohorts or treat missing body text as an invalid rating.

## Q25 — preliminary relationship between review BODY text and rating
q25_rating_text_presence.csv cross-tabulates mutually exclusive text states by valid star rating (1..5). q25_rating_text_length.csv reports character and whitespace-word means and extrema, CONDITIONED on nonblank string bodies. q25_rating_text_features.csv reports nonexclusive short, long, exclamation and question presence within nonblank bodies. All output rates are Q19-validated. Invalid rating rows are excluded from per-star strata but counted separately. Only raw review BODY is assessed; title and metadata text are not substituted. This is a descriptive association on raw pre-dedup records, not a sentiment analysis, a significance test, a leakage-safe held-out model result, or a causal finding. Missing text never changes a chronological review position.

## Q24 — Unicode script and character diagnostics for review body
q24_unicode_script_profile.csv counts alphabetic Unicode code points and review bodies with each approximate Unicode-block script label; such labels are not detected languages. q24_script_patterns.csv partitions all string bodies into no letters, a single script, or multiple scripts. q24_unicode_flags.csv counts possible encoding/control warnings per BODY, with overlap allowed; all denominators are registered and validated by Q19. The pre-existing text replacement/surrogate/C0-control flags are reconciled exactly. Emoji, natural multilingual writing and Persian zero-width non-joiners are not flagged as errors. BiDi controls can be legitimate; a warning is not proof of corruption. Neither language classification nor actual character-level repair is performed.

## Q23 — very short and very long review body texts
q23_short_long_thresholds.csv reports short nonblank bodies (1..K whitespace words) and long string bodies (>L Unicode code points), using the existing Q22 histograms. The two pre-existing A thresholds (configurable) are labeled PRIMARY; additional thresholds are sensitivity comparisons, not universal data-quality cutoffs. Whitespace-only body strings are not counted short; however extremely long whitespace-only strings can meet the long threshold, as the original A rule does. Missing, null and wrong-type bodies have no assigned length. Rates are shown both against the applicable reference string set and against all parsed review objects; Q19 verifies every rate. The short/long intersection cannot be reconstructed from separate 1D histograms, so no claim of their unique union is made. Raw inputs, 5+10 review positions, and all older Q01-Q22 reports remain unchanged.

## Q21 — evidence-linked initial quality decisions
q21_initial_decisions.csv lists observed issues, count units, evidence sources, task-specific actions, stages and rationale. q21_policy_catalog.json lists all action contracts, including policies not observed in this scan. Unknown rules require manual triage; no observed count is a directive to delete source rows. Issue counts overlap, group-based counts cannot be added to row counts, and Q15/Q16 statistical flags are subsets of valid measurements. Q03 readiness counts are before dedup and are not final 5+10 cohorts. No cleaning, feature fitting, joining or model training occurs here.
