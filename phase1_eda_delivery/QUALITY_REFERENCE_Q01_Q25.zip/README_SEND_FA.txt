بستهٔ گزارش کامل ممیزی کیفیت آمازون — Q01 تا Q25 و Q17
Run: 20261106T043348Z_4216fe6a
Status: completed
Audit scope: dataset

دسته‌ها:
Electronics: completed; reviews=43886944, metadata=1610012
Beauty_and_Personal_Care: completed; reviews=23911390, metadata=1028914
Appliances: completed; reviews=2128605, metadata=94327
All_Beauty: completed; reviews=701528, metadata=112590

پوشه outputs/full شامل همهٔ گزارش‌های CSV، JSON و Markdown هر دسته است.
پوشه comparison شامل مقایسهٔ چهار دسته در Q17 است (اگر اجرای آن کامل شده باشد).
فایل RUN_MANIFEST.json وضعیت اجرا، زمان مبنا و هش پیکربندی را نگه می‌دارد.
پوشه logs برای تشخیص خطاهای اجرایی و preflight برای اعتبارسنجی ورودی‌هاست.

داده‌های خام، متن کامل نقدها، پایگاه‌های SQLite و نسخه‌های بازشدهٔ GZIP در این ZIP نیستند.
آمار هر فایل، قبل از حذف کپی‌های کامل و بر مبنای قراردادهای Q01 تا Q25 است.
برخی هشدارها و پرت‌ها به معنی خراب بودن یا لزوم حذف داده نیستند.
نکته: کد کیفیت و ساختار برای JSON دارای کلید تکراری یا مقدار غیر استاندارد تفاوت پارس دارند.
تمام دیتاست یعنی اسکن کامل فایل‌های معرفی‌شده در config، نه اثبات کامل بودن آرشیو ناشر.
