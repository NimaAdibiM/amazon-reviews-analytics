Amazon Reviews 2023 — Phase 1 EDA results
The outputs/ directory contains this exact local run and all four categories.
See outputs/validation/real_validation.json and outputs/full/RUN_STATUS.json.
Never treat PASS_INTERNAL_ONLY or FAIL as verified real analysis.
The source datasets are NOT in this archive.
Even PASS_REAL_Q_MATCHED is input/output consistency evidence, not full scientific E01–E57 approval.
