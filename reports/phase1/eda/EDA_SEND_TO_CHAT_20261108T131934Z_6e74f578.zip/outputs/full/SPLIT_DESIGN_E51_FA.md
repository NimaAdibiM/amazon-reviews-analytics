# طرح تقسیم زمانی بدون نشت (E51)

**وضعیت: فقط طراحی؛ تاریخ‌های برش هنوز انتخاب نشده و هیچ تقسیم واقعی اجرا نشده است.**

واحد تقسیم، محصول جهانی یکتا با شناسهٔ `parent_asin` است. ابتدا کپی‌های دقیق بین چهار فایل حذف و تعارض‌ها و تساوی مرزی تعیین می‌شوند.

برای هر محصول، بلوک زمانی صرفاً با زمان نقد پنجم (`t5`) تعیین می‌شود. ورود برچسب به هر بلوک فقط وقتی مجاز است که نقد پانزدهم (`t15`) تا پایان همان بلوک مشاهده شده باشد.

محصول بدون ۱۵ نقد معتبر یا با برچسب نارسیده **صفر برچسب نمی‌گیرد** و به بلوک زمانی بعدی منتقل نمی‌شود.

## شروط اجباری

- Reconcile and exact-deduplicate globally BEFORE splitting; no product appears in two splits.
- Define t5 from 5th valid observed review and t15 from 15th, after boundary-tie exclusions.
- Time-block membership is determined ONLY by t5; a label is usable ONLY if t15 is no later than the end of its own block.
- Unmatured labels are censored, never treated as negative or transferred to a later block.
- Freeze block cutoffs and outcome observation window before model tuning; audit time-dependent selection.
- Preprocessing, imputation, vocabulary, IDF, category priors, text embeddings learned from corpus, scaling and thresholds fit on training only.
- Tune on validation; evaluate test only once after choices are frozen.
- Do not use future reviews 6–15, t15, crawl-time average_rating/rating_number, historical-unknown price or snapshot helpful_vote as predictors.
- Keep identical evaluation products/splits/model families and comparable tuning budgets for S versus ST.
- Use product-level paired loss and uncertainty with clustering/dependence considered; report each category and equal-category primary aggregate.

## کارهای باز

- Choose calendar dates using actual follow-up coverage without looking at test outcome associations
- Run split only with four full verified raw inputs and report dropout/censoring per category
- Evaluate subgroup and category distribution shift, no fitted models in Phase 1

این مستند، ارزیابی S در برابر ST یا آزمون نهایی را انجام‌شده معرفی نمی‌کند.
