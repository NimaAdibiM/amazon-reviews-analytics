# E09 / E26 / E27 — شواهد فراوانی دقیق و حساسیت به کپی

این خروجی فقط برای **دامنهٔ ورودی همین اجرا** محاسبه شده است؛ اجرای مصنوعی یا پیش‌نمایش، شاهد جمعیت واقعی نیست.
روش صدک دقیق: آمارهٔ مرتب‌شده در رتبهٔ `ceil(p × n)` (با رتبه‌گذاری از ۱). این روش با صدک درون‌یابی‌شدهٔ خطی B یکسان نیست. تعریف قبل از مقایسه باید ثابت باشد.
پرت: کمتر از چارک اول منهای ۱٫۵ برابر فاصلهٔ بین چارکی، یا بیشتر از چارک سوم به‌علاوهٔ ۱٫۵ برابر آن. مرزها **سخت‌گیرانه** هستند؛ مساوی مرز پرت نیست. هیچ داده‌ای خودکار حذف نمی‌شود.
فراوانی‌های دقیق در SQLite روی دیسک تجمیع می‌شوند؛ مقادیر صحیح بزرگ‌تر از ۲^۵۳ به‌جای گردشدن، از استنتاج «دقیق» خارج و در دلیل عدم امکان ثبت می‌شوند.
خروجی‌های بازه‌ای نمودارهای قدیمی حفظ شده‌اند و باید با این فایل مکمل خوانده شوند.

## محدودیت E09
حساسیت نقدها فقط برای **هستهٔ معتبر توالی** با شناسهٔ والد، زمان و امتیاز معتبر است و حذف کپی در سطح تمام چهار دسته و با برابری کاننیکال رکورد انجام شده است. حساسیت فراداده محدود به رکوردهای دارای شناسهٔ والد معتبر و حذف کپی در همان دسته/محصول است. این نتایج معادل حساسیت تمام رکوردهای خام و تمام متغیرها نیست؛ E09 تا گسترش آن باز می‌ماند.

## All_Beauty — E26/E27

| نقش | شاخص | شمار معتبر | وضعیت دقت | میانه | چارک ۱ | چارک ۳ | پرت دقیق |
|---|---|---:|---|---:|---:|---:|---:|
| reviews | `rating` | 701528 | exact_disk_frequency | 5 | 3 | 5 | 0 |
| reviews | `title_chars` | 701528 | exact_disk_frequency | 16 | 10 | 27 | 39924 |
| reviews | `body_chars` | 700808 | exact_disk_frequency | 102 | 44 | 209 | 51908 |
| reviews | `body_words` | 700808 | exact_disk_frequency | 19 | 8 | 40 | 50239 |
| reviews | `helpful_vote` | 701528 | exact_disk_frequency | 0 | 0 | 1 | 54372 |
| reviews | `title_chars_all_strings` | 701528 | exact_disk_frequency | 16 | 10 | 27 | 39924 |
| reviews | `title_words_all_strings` | 701528 | exact_disk_frequency | 3 | 2 | 5 | 48956 |
| reviews | `body_chars_all_strings` | 701528 | exact_disk_frequency | 102 | 44 | 209 | 51908 |
| reviews | `body_words_all_strings` | 701528 | exact_disk_frequency | 19 | 8 | 40 | 50239 |
| reviews | `review_image_entries` | 701528 | exact_disk_frequency | 0 | 0 | 0 | 59684 |
| metadata | `price` | 17704 | exact_disk_frequency | 16.99 | 9.99 | 29.9 | 1341 |
| metadata | `average_rating` | 112590 | exact_disk_frequency | 4 | 3.4 | 4.5 | 3676 |
| metadata | `rating_number` | 112590 | exact_disk_frequency | 9 | 3 | 28 | 13842 |
| metadata | `title_chars_all_strings` | 112590 | exact_disk_frequency | 114 | 67 | 158 | 68 |
| metadata | `features_entries` | 112590 | exact_disk_frequency | 0 | 0 | 0 | 17377 |
| metadata | `features_chars` | 112590 | exact_disk_frequency | 0 | 0 | 0 | 17377 |
| metadata | `description_entries` | 112590 | exact_disk_frequency | 0 | 0 | 0 | 19162 |
| metadata | `description_chars` | 112590 | exact_disk_frequency | 0 | 0 | 0 | 19162 |
| metadata | `images_entries` | 112590 | exact_disk_frequency | 6 | 2 | 7 | 10 |
| metadata | `videos_entries` | 112590 | exact_disk_frequency | 0 | 0 | 0 | 15882 |
| metadata | `categories_entries` | 112590 | exact_disk_frequency | 0 | 0 | 0 | 0 |
| metadata | `bought_together_entries` | 0 | no_valid_observations | — | — | — | — |
| metadata | `details_keys` | 112590 | exact_disk_frequency | 6 | 3 | 7 | 310 |

### E09 — فراداده با والد معتبر

| سنجه | خام | پس از حذف کپی | اختلاف | فاصلهٔ تغییرکل توزیع |
|---|---:|---:|---:|---:|
| `price` | 17704 | 17704 | 0 | 0 |
| `average_rating` | 112590 | 112590 | 0 | 0 |
| `rating_number` | 112590 | 112590 | 0 | 0 |
| `images_entries` | 112590 | 112590 | 0 | 0 |

## Appliances — E26/E27

| نقش | شاخص | شمار معتبر | وضعیت دقت | میانه | چارک ۱ | چارک ۳ | پرت دقیق |
|---|---|---:|---|---:|---:|---:|---:|
| reviews | `rating` | 2128605 | exact_disk_frequency | 5 | 4 | 5 | 330117 |
| reviews | `title_chars` | 2128605 | exact_disk_frequency | 17 | 10 | 29 | 100893 |
| reviews | `body_chars` | 2126540 | exact_disk_frequency | 88 | 37 | 195 | 177884 |
| reviews | `body_words` | 2126540 | exact_disk_frequency | 16 | 7 | 37 | 172197 |
| reviews | `helpful_vote` | 2128605 | exact_disk_frequency | 0 | 0 | 0 | 408620 |
| reviews | `title_chars_all_strings` | 2128605 | exact_disk_frequency | 17 | 10 | 29 | 100893 |
| reviews | `title_words_all_strings` | 2128605 | exact_disk_frequency | 3 | 2 | 5 | 156419 |
| reviews | `body_chars_all_strings` | 2128605 | exact_disk_frequency | 88 | 37 | 195 | 177884 |
| reviews | `body_words_all_strings` | 2128605 | exact_disk_frequency | 16 | 7 | 37 | 172197 |
| reviews | `review_image_entries` | 2128605 | exact_disk_frequency | 0 | 0 | 0 | 84949 |
| metadata | `price` | 46726 | exact_disk_frequency | 26.99 | 14.99 | 58.13 | 5473 |
| metadata | `average_rating` | 94327 | exact_disk_frequency | 4.3 | 3.8 | 4.7 | 4977 |
| metadata | `rating_number` | 94327 | exact_disk_frequency | 13 | 3 | 53 | 13791 |
| metadata | `title_chars_all_strings` | 94327 | exact_disk_frequency | 93 | 53 | 146 | 17 |
| metadata | `features_entries` | 94327 | exact_disk_frequency | 4 | 2 | 5 | 744 |
| metadata | `features_chars` | 94327 | exact_disk_frequency | 232 | 70 | 762 | 2814 |
| metadata | `description_entries` | 94327 | exact_disk_frequency | 1 | 0 | 1 | 16712 |
| metadata | `description_chars` | 94327 | exact_disk_frequency | 116 | 0 | 499 | 7730 |
| metadata | `images_entries` | 94327 | exact_disk_frequency | 3 | 1 | 7 | 11 |
| metadata | `videos_entries` | 94327 | exact_disk_frequency | 0 | 0 | 3 | 13381 |
| metadata | `categories_entries` | 94327 | exact_disk_frequency | 4 | 3 | 4 | 3285 |
| metadata | `bought_together_entries` | 0 | no_valid_observations | — | — | — | — |
| metadata | `details_keys` | 94327 | exact_disk_frequency | 10 | 7 | 14 | 2313 |

### E09 — فراداده با والد معتبر

| سنجه | خام | پس از حذف کپی | اختلاف | فاصلهٔ تغییرکل توزیع |
|---|---:|---:|---:|---:|
| `price` | 46726 | 46726 | 0 | 0 |
| `average_rating` | 94327 | 94327 | 0 | 0 |
| `rating_number` | 94327 | 94327 | 0 | 0 |
| `images_entries` | 94327 | 94327 | 0 | 0 |

## Beauty_and_Personal_Care — E26/E27

| نقش | شاخص | شمار معتبر | وضعیت دقت | میانه | چارک ۱ | چارک ۳ | پرت دقیق |
|---|---|---:|---|---:|---:|---:|---:|
| reviews | `rating` | 23911390 | exact_disk_frequency | 5 | 4 | 5 | 4115909 |
| reviews | `title_chars` | 23911390 | exact_disk_frequency | 16 | 10 | 27 | 1321983 |
| reviews | `body_chars` | 23874796 | exact_disk_frequency | 107 | 46 | 219 | 1706964 |
| reviews | `body_words` | 23874796 | exact_disk_frequency | 20 | 9 | 42 | 1686343 |
| reviews | `helpful_vote` | 23911390 | exact_disk_frequency | 0 | 0 | 1 | 1886337 |
| reviews | `title_chars_all_strings` | 23911390 | exact_disk_frequency | 16 | 10 | 27 | 1321983 |
| reviews | `title_words_all_strings` | 23911390 | exact_disk_frequency | 3 | 2 | 5 | 1584875 |
| reviews | `body_chars_all_strings` | 23911390 | exact_disk_frequency | 107 | 46 | 219 | 1706964 |
| reviews | `body_words_all_strings` | 23911390 | exact_disk_frequency | 20 | 8 | 42 | 1614956 |
| reviews | `review_image_entries` | 23911390 | exact_disk_frequency | 0 | 0 | 0 | 1696925 |
| metadata | `price` | 380597 | exact_disk_frequency | 15.99 | 9.98 | 29 | 34920 |
| metadata | `average_rating` | 1028914 | exact_disk_frequency | 4.2 | 3.7 | 4.6 | 35293 |
| metadata | `rating_number` | 1028914 | exact_disk_frequency | 19 | 5 | 78 | 150991 |
| metadata | `title_chars_all_strings` | 1028914 | exact_disk_frequency | 98 | 59 | 156 | 492 |
| metadata | `features_entries` | 1028914 | exact_disk_frequency | 4 | 0 | 5 | 56 |
| metadata | `features_chars` | 1028914 | exact_disk_frequency | 213 | 0 | 821 | 7209 |
| metadata | `description_entries` | 1028914 | exact_disk_frequency | 1 | 0 | 1 | 110368 |
| metadata | `description_chars` | 1028914 | exact_disk_frequency | 57 | 0 | 439 | 86665 |
| metadata | `images_entries` | 1028914 | exact_disk_frequency | 5 | 2 | 7 | 689 |
| metadata | `videos_entries` | 1028914 | exact_disk_frequency | 0 | 0 | 1 | 162581 |
| metadata | `categories_entries` | 1028914 | exact_disk_frequency | 4 | 4 | 5 | 22411 |
| metadata | `bought_together_entries` | 0 | no_valid_observations | — | — | — | — |
| metadata | `details_keys` | 1028914 | exact_disk_frequency | 8 | 5 | 9 | 23193 |

### E09 — فراداده با والد معتبر

| سنجه | خام | پس از حذف کپی | اختلاف | فاصلهٔ تغییرکل توزیع |
|---|---:|---:|---:|---:|
| `price` | 380597 | 380597 | 0 | 0 |
| `average_rating` | 1028914 | 1028914 | 0 | 0 |
| `rating_number` | 1028914 | 1028914 | 0 | 0 |
| `images_entries` | 1028914 | 1028914 | 0 | 0 |

## Electronics — E26/E27

| نقش | شاخص | شمار معتبر | وضعیت دقت | میانه | چارک ۱ | چارک ۳ | پرت دقیق |
|---|---|---:|---|---:|---:|---:|---:|
| reviews | `rating` | 43886942 | exact_disk_frequency | 5 | 4 | 5 | 7616404 |
| reviews | `title_chars` | 43886942 | exact_disk_frequency | 18 | 10 | 31 | 1809225 |
| reviews | `body_chars` | 43845751 | exact_disk_frequency | 122 | 48 | 271 | 3788273 |
| reviews | `body_words` | 43845751 | exact_disk_frequency | 23 | 9 | 51 | 3684579 |
| reviews | `helpful_vote` | 43886940 | exact_disk_frequency | 0 | 0 | 0 | 9421755 |
| reviews | `title_chars_all_strings` | 43886944 | exact_disk_frequency | 18 | 10 | 31 | 1809225 |
| reviews | `title_words_all_strings` | 43886944 | exact_disk_frequency | 3 | 2 | 6 | 1407647 |
| reviews | `body_chars_all_strings` | 43886944 | exact_disk_frequency | 122 | 48 | 271 | 3788273 |
| reviews | `body_words_all_strings` | 43886944 | exact_disk_frequency | 23 | 9 | 51 | 3684579 |
| reviews | `review_image_entries` | 43886944 | exact_disk_frequency | 0 | 0 | 0 | 2023745 |
| metadata | `price` | 526449 | exact_disk_frequency | 22.9 | 11.99 | 60 | 74822 |
| metadata | `average_rating` | 1610012 | exact_disk_frequency | 4.2 | 3.6 | 4.6 | 65459 |
| metadata | `rating_number` | 1610012 | exact_disk_frequency | 12 | 3 | 49 | 233436 |
| metadata | `title_chars_all_strings` | 1610012 | exact_disk_frequency | 122 | 76 | 174 | 3671 |
| metadata | `features_entries` | 1610012 | exact_disk_frequency | 5 | 0 | 5 | 1288 |
| metadata | `features_chars` | 1610012 | exact_disk_frequency | 290 | 0 | 740 | 32690 |
| metadata | `description_entries` | 1610012 | exact_disk_frequency | 1 | 0 | 1 | 270665 |
| metadata | `description_chars` | 1610012 | exact_disk_frequency | 97 | 0 | 637 | 98667 |
| metadata | `images_entries` | 1610012 | exact_disk_frequency | 6 | 2 | 7 | 2490 |
| metadata | `videos_entries` | 1610012 | exact_disk_frequency | 0 | 0 | 0 | 400405 |
| metadata | `categories_entries` | 1610012 | exact_disk_frequency | 4 | 4 | 5 | 176541 |
| metadata | `bought_together_entries` | 0 | no_valid_observations | — | — | — | — |
| metadata | `details_keys` | 1610012 | exact_disk_frequency | 10 | 7 | 13 | 80302 |

### E09 — فراداده با والد معتبر

| سنجه | خام | پس از حذف کپی | اختلاف | فاصلهٔ تغییرکل توزیع |
|---|---:|---:|---:|---:|
| `price` | 526449 | 526449 | 0 | 0 |
| `average_rating` | 1610012 | 1610012 | 0 | 0 |
| `rating_number` | 1610012 | 1610012 | 0 | 0 |
| `images_entries` | 1610012 | 1610012 | 0 | 0 |

## E09 — هستهٔ توالی معتبر سراسری

وضعیت: computed؛ دامنه: global valid parent/time/rating sequence core

| سنجه | خام | یکتا | فاصلهٔ تغییرکل توزیع |
|---|---:|---:|---:|
| `rating` | 70628465 | 69878093 | 0.00020417597 |
| `helpful_vote` | 70628461 | 69878089 | 3.3831427e-05 |
| `body_chars_all_strings` | 70628465 | 69878093 | 0.00023781626 |
| `body_words_all_strings` | 70628465 | 69878093 | 0.00016162573 |
| `title_chars_all_strings` | 70628465 | 69878093 | 8.6393225e-05 |
| `review_image_entries` | 70628465 | 69878093 | 4.5507785e-05 |

## وضعیت پذیرش

- E26: پیاده‌سازی محاسبهٔ دقیق تکمیل شد؛ نیازمند اجرای کامل واقعی و ممیزی دقت/هزینه.
- E27: قاعده و شمارش پرت‌ها دقیق هستند، ولی تفسیر علمی دادهٔ واقعی و تعریف نامعتبرها نیازمند بازبینی است.
- E09: جمعیت‌های حساسیت صریح و قابل‌آزمون‌اند، اما هنوز همهٔ رکوردها/سنجه‌ها پوشش ندارند.
- وقتی بزرگی یک عدد مانع دقت IEEE-754 شود، نتیجهٔ دقیق منتشر نمی‌شود.

