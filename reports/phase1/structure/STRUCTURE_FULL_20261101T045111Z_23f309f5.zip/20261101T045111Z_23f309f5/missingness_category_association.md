# S24 — Association between category and information unavailability

Data scope: entire_supplied_dataset_files
Descriptive association only; no p-value and no claim of MCAR/MAR/MNAR or causality.
Rows are drawn from the same S22/S23 counts; no extra raw-file pass.
Cramer's V is between 0 and 1 when defined; it measures association, not causation.
Non-independent reviews and possible overlap between category files limit inference.

| Modality | Level | Missing rate gap (pp) | Cramer's V | Status |
|---|---|---:|---:|---|
| review_text_body | review_record | 0.06 | 0.0083 | different_observed_category_rates |
| review_text | review_record | 0.00 | N/A | no_variation_in_availability_indicator |
| review_images | review_record | 4.52 | 0.0541 | different_observed_category_rates |
| product_images | review_record_after_parent_join | 0.01 | 0.0039 | different_observed_category_rates |
| product_price | review_record_after_parent_join | 48.72 | 0.1429 | different_observed_category_rates |
| product_images | metadata_record | 0.02 | 0.0066 | different_observed_category_rates |
| product_price | metadata_record | 33.81 | 0.1063 | different_observed_category_rates |
