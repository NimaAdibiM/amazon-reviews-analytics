# Structural data audit

Run: 20261101T045111Z_23f309f5
Scope: entire_supplied_dataset_files
Category: All_Beauty

## Files

| File | Lines read | JSON objects | Blank | Parse errors | Non-object JSON | EOF reached | Columns |
|---|---:|---:|---:|---:|---:|---|---:|
| reviews | 701,528 | 701,528 | 0 | 0 | 0 | True | 10 |
| metadata | 112,590 | 112,590 | 0 | 0 | 0 | True | 14 |

Line counts are internally checked: JSON objects + blank + parse errors + non-object JSON = lines read.
A completed scan does not mean the input has no invalid or non-object lines.

## Parse issue reasons

Only error categories and up to ten line-number examples per file are saved; raw review content is not included.
- reviews: {}
  First examples: []
- metadata: {}
  First examples: []


## Top-level column inventory

Column count means the UNION of field names across readable JSON objects, not the number of keys in the first row.
Reference names come from the dataset publisher. An extra field is not necessarily an error; a reference field not seen in a preview is not proven absent from the full file.

### reviews
Observed field names: asin, helpful_vote, images, parent_asin, rating, text, timestamp, title, user_id, verified_purchase
Reference fields not observed in scanned scope: (none)
Additional observed field names: (none)
Keys per record distribution: {"10": 701528}
Detailed per-field presence: column_inventory.csv (denominator: 701528 JSON objects)

### metadata
Observed field names: average_rating, bought_together, categories, description, details, features, images, main_category, parent_asin, price, rating_number, store, title, videos
Reference fields not observed in scanned scope: (none)
Additional observed field names: (none)
Keys per record distribution: {"14": 112590}
Detailed per-field presence: column_inventory.csv (denominator: 112590 JSON objects)


## Field presence, null and empty values

All counts use the parsed JSON object-row count as their denominator.
Absent key != explicit null != blank/whitespace-only string != [] != {}.
Blank strings are detected without changing the original data.
Nonempty here means not one of those empty cases; it does NOT certify semantic usability or expected type.
The detailed counts for each field are in column_inventory.csv.


## Field types and meanings

Raw JSON value types are counted separately from analytical meaning.
Reference expectations are role-specific (review title != product title).
Non-null type deviations are flags for investigation, not automatic proof of bad data.
Explicit null values are counted by raw type, but are not treated as type deviations.
Reference types and all observed type counts: column_inventory.csv / field_schema.csv.

reviews — non-null deviations from publisher reference: none observed
metadata — non-null deviations from publisher reference: none observed

## Nested field structure

Top-level arrays and objects remain ONE field each; elements and keys are not extra top-level rows.
nested_containers.csv: container frequency, empty count, total elements/keys, min/max/mean size.
container_schema.csv: types of direct array members or object values.
nested_child_types.csv: types of keys inside array-of-object elements and direct object keys.
Nested child keys are examined two structural levels deep; deeper dictionaries are not recursively expanded.
For memory safety, at most 5000 distinct child names per field/context are itemized; any overflow is reported in summary.json.

reviews: 1 array/object shapes; 4 tracked child-key paths; overflow=[]
metadata: 6 array/object shapes; 472 tracked child-key paths; overflow=[]

## Identifier roles and counts

Amazon review user_id identifies a reviewer, asin identifies an item/variant,
and parent_asin groups product variants. Join review and metadata by parent_asin.
These are dataset identifiers, not verified real-world identities or guaranteed unique review IDs.

- reviews.user_id (identifier): Reviewer identifier; not a real-world identity; 631,986 distinct IDs; 701,528 occurrences.
- reviews.asin (identifier): Identifier of the reviewed product variant; 115,709 distinct IDs; 701,528 occurrences.
- reviews.parent_asin (join_key): Product-parent ID used to join to metadata; 112,565 distinct IDs; 701,528 occurrences.
- metadata.parent_asin (candidate_primary_key): Parent product ID; uniqueness checked separately; 112,590 distinct IDs; 112,590 occurrences.

## Identifier usability (S11)

Counts use parseable JSON-object rows, not physical lines, as denominators.
Non-indexable ID reasons are exclusive: absent, null, wrong type, blank string, or invalid UTF-8.
IDs with surrounding whitespace remain indexable but are flagged because joins are exact.
No ID strings are trimmed, converted, or repaired. See identifiers.csv.

- reviews.user_id: indexable=701,528/701,528, unindexable=0 (absent=0; null=0; wrong_type=0; blank=0; invalid_utf8=0); indexable_with_surrounding_whitespace=0.
- reviews.asin: indexable=701,528/701,528, unindexable=0 (absent=0; null=0; wrong_type=0; blank=0; invalid_utf8=0); indexable_with_surrounding_whitespace=0.
- reviews.parent_asin: indexable=701,528/701,528, unindexable=0 (absent=0; null=0; wrong_type=0; blank=0; invalid_utf8=0); indexable_with_surrounding_whitespace=0.
- metadata.parent_asin: indexable=112,590/112,590, unindexable=0 (absent=0; null=0; wrong_type=0; blank=0; invalid_utf8=0); indexable_with_surrounding_whitespace=0.

## Variant ASIN to parent mapping (S12)

Each usable pair is taken from the SAME review record; absent/non-string/blank IDs are excluded.
A parent with multiple ASINs is normal. An ASIN linked to multiple parents is flagged, not automatically corrected.
Repeated observations of the same pair are not distinct variant-parent relationships.
Pair counts refer only to scanned files; no global product-catalog consistency is claimed.
See relationships.csv for the counts, including excluded rows and coverage.

- distinct_asin_parent_pairs: 115709
- review_rows_with_usable_asin_parent_pair: 701528
- review_rows_without_usable_asin_parent_pair: 0
- distinct_asins_with_parent_link: 115709
- distinct_parents_with_asin_link: 112565
- asin_parent_pairs_occurring_more_than_once: 66850
- asins_linked_to_multiple_parents: 0
- parents_linked_to_multiple_asins: 995

## File relationship (S13)

Join key: reviews.parent_asin = metadata.parent_asin.
Do NOT join reviews.asin to metadata.parent_asin; asin is a variant ID.
A match compares original ID strings exactly, without trimming or casting.
This audit counts possible matches without creating a new merged dataset.
Each review also refers to a user_id and a reviewed asin/variant.
Metadata key uniqueness is measured, not assumed. Missing or non-indexable identifiers are counted separately.

- review_join_field: parent_asin
- metadata_join_field: parent_asin
- join_comparison: exact_string_equality_no_normalization
- shared_product_ids: 112565
- review_product_ids_without_metadata: 0
- metadata_product_ids_without_reviews: 25
- review_rows_with_matching_metadata_id: 701528
- metadata_ids_with_multiple_rows: 0
- max_metadata_rows_per_product_id: 1
- distinct_asin_parent_pairs: 115709
- review_rows_with_usable_asin_parent_pair: 701528
- review_rows_without_usable_asin_parent_pair: 0
- distinct_asins_with_parent_link: 115709
- distinct_parents_with_asin_link: 112565
- asin_parent_pairs_occurring_more_than_once: 66850
- asins_linked_to_multiple_parents: 0
- parents_linked_to_multiple_asins: 995
- potential_inner_join_rows: 701528
- matched_share_of_reviews_with_indexable_product_id: 1.0
- metadata_key_unique_among_indexable_ids: True
- metadata_key_complete_in_scanned_scope: True
- metadata_parent_key_unique_and_complete_in_scanned_scope: True
- metadata_rows_without_usable_parent_key: 0
- metadata_extra_rows_after_first_per_parent: 0
- review_rows_matching_multiple_metadata_rows: 0
- extra_inner_join_rows_from_metadata_repetition: 0
- potential_left_join_rows: 701528
- review_object_rows_denominator: 701528
- review_rows_with_usable_parent_id: 701528
- review_rows_without_usable_parent_id: 0
- review_rows_with_usable_parent_but_no_metadata: 0
- review_rows_without_metadata_match_total: 0
- review_distinct_usable_parent_ids_denominator: 112565
- metadata_distinct_usable_parent_ids_denominator: 112590
- matched_percent_of_all_review_object_rows: 100.0
- matched_percent_of_review_rows_with_usable_parent_id: 100.0
- matched_percent_of_distinct_review_parent_ids: 100.0
- both_input_files_reached_eof: True
- coverage_scope_note: Coverage applies only to parsed JSON-object rows in these two scanned inputs. Preview or independently sampled files cannot establish full-dataset coverage. Numerators count original review rows, before any join multiplication; unusable parent IDs are not matched or normalized.
- interpretation: All results refer to scanned objects only; preview mode does not establish full-file key uniqueness or completeness. Multiple metadata rows for one parent may multiply joined review rows, but do not prove full-record duplicates. Join row counts are projected without materializing a join.

## Metadata parent key and join multiplicity (S14)

A reliable one-row-per-review join needs metadata.parent_asin to be present and unique in the scanned metadata records.
Uniqueness among usable keys is not the same as a complete key; empty metadata cannot establish both.
Metadata key complete (scanned scope): True
Metadata parent key unique and complete (scanned scope): True
Review rows with multiple metadata matches: 0
Additional inner-join rows from multiple metadata matches: 0
Projected left-join row count: 701528
Repeated parent IDs do NOT necessarily mean duplicate full metadata records.
All projected counts assume exact original-string equality and no normalization.
In preview mode these conclusions apply ONLY to the scanned prefixes.


## Review-to-metadata coverage (S15)

The denominator of each percentage is explicit; these are original review rows, not rows after joining.
Review rows with metadata: 701,528 / 701,528 (100.0%).
Review rows with usable parent ID and matching metadata: 701,528 / 701,528 (100.0%).
Distinct review parent IDs with metadata: 112,565 / 112,565 (100.0%).
Reviews with a usable parent but no metadata: 0.
Reviews without a usable parent: 0.
All reviews without a metadata match: 0.
Metadata-only parent IDs: 25.
Undefined percentages have null values in the JSON/CSV outputs when their denominator is zero.
A match counts one original review once, even if metadata contains multiple rows for that parent.
Preview mode, sampled files, and malformed JSON limit what coverage means; do not generalize these values to every Amazon review.


## Observed review date range (S18)

The publisher reports May 1996 through September 2023 for the ENTIRE corpus;
this is not the guaranteed range of any selected category or local sample.
All range statistics below use only convertible timestamps in scanned review objects.
No timestamps are filtered or changed; date-range plausibility is examined in S19.

- Review times: 701,528 convertible records; earliest=2000-11-01T04:24:18+00:00; latest=2023-09-09T00:39:36.666000+00:00; span_days=8346.843966042.
- Scope: entire_supplied_file; reached_eof=True. These are observed review dates, not purchase dates or collection dates.


## Temporal plausibility and invalid timestamps (S19)

Technical failures (missing, null, wrong type, out of Python datetime range) are counted separately.
A convertible timestamp outside the published corpus-wide time window is only flagged for review.
No local timestamp is filtered or corrected; flags do not prove the configured epoch unit.
Within/outside the reference window partitions convertible timestamps; after_as_of may overlap either group.
Reference bounds and the audit as-of time are recorded in temporal_variables.csv and summary.json.

- reviews: conversion_states={"absent_key": 0, "convertible": 701528, "explicit_null": 0, "outside_datetime_range": 0, "wrong_raw_type": 0}, plausibility_flags={"after_as_of": 0, "at_or_after_reference_end": 0, "before_reference_start": 0, "outside_reference_window": 0, "within_reference_window": 701528}

## Same-product timestamp ties and order precision (S20)

Only equal raw epoch values within the same usable parent_asin are ties.
An equality across positions 5/6 or 15/16 leaves the review-set membership ambiguous until a deterministic tie-break rule is defined.
Products with >=15 convertible timestamps are NOT yet proven to have 15 valid ratings/texts for the final prediction task.
Whole-second alignment is reported but does not prove original timestamp precision.
See temporal_ties.csv and temporal_ordering in summary.json.
- Parents with timestamp collisions: 4,947.
- Parents tied across positions 5/6: 321.
- Parents tied across positions 15/16: 92.


## Temporal variable (S17)

Review timestamps are Unix epoch values interpreted with an explicitly configured unit; all displayed dates are UTC.
The default is milliseconds, provisionally based on the publisher's published millisecond-scale example; the local timestamp unit needs confirmation.
The published schema calls the field timestamp but a sample calls it sort_timestamp; neither is silently substituted for the other.
The metadata file has no documented review timestamp; do not interpret product attributes as historical snapshots.
See temporal_variables.csv and files.reviews.temporal in summary.json.

- reviews: {"audit_as_of_utc": "2026-11-01T04:51:11.751315+00:00", "convertible_rows_with_indexable_parent": 701528, "counts": {"absent_key": 0, "convertible": 701528, "explicit_null": 0, "outside_datetime_range": 0, "wrong_raw_type": 0}, "earliest_convertible_utc": "2000-11-01T04:24:18+00:00", "field": "timestamp", "latest_convertible_utc": "2023-09-09T00:39:36.666000+00:00", "meaning": "Publisher-documented time of a review; not purchase time", "note": "The publisher's schema documents timestamp, but its public sample uses sort_timestamp. This audit does not silently treat them as synonyms. The publisher's global date range is a plausibility reference, not a row filter or a proof that an out-of-window record is wrong. Future-time flags are relative to the recorded audit_as_of_utc.", "observed_range_scope": "only successfully parsed records in this scan", "observed_span_days": 8346.843966042, "plausibility_flags": {"after_as_of": 0, "at_or_after_reference_end": 0, "before_reference_start": 0, "outside_reference_window": 0, "within_reference_window": 701528}, "reference_end_exclusive_utc": "2023-10-01T00:00:00+00:00", "reference_full_corpus_period": "May 1996 through September 2023", "reference_period_scope": "publisher's entire Amazon Reviews'23 dataset, NOT this category", "reference_start_inclusive_utc": "1996-05-01T00:00:00+00:00", "sort_timestamp_observed_rows": 0, "status": "audited_review_timestamp", "timezone": "UTC", "unit": "ms", "unit_status": "configured_assumption_to_verify_on_local_data", "whole_second_aligned_convertible_rows": 166694, "whole_second_alignment_note": "Divisibility alone does not prove timestamp measurement precision"}
- metadata: {"field": null, "note": "Product metadata is a crawl-time snapshot; no review timestamp is expected.", "status": "not_applicable_no_documented_review_timestamp", "unit": null}

## Identifier repetition

Repeated identifier values do not by themselves mean duplicate review records.
'values_occurring_more_than_once' counts distinct identifiers with frequency > 1; 'repeated_occurrences_after_first' counts additional occurrences beyond the first.
See identifiers.csv for all four identifier roles.


## Multimodal field and source inventory (S21)

A review is the sample. Product metadata is a separate observation attached only through a parent_asin match.
Observed source fields indicate presence somewhere in the scanned scope, NOT per-review nonempty content or downloadable image media.
Review images and product images are different; product-page rating aggregates and prices are not assumed historically available.
See modality_inventory.csv and modality_inventory in summary.json.

- review_text (reviews): all_fields_observed_in_scan; observed=title,text; requires_join=False
- review_rating (reviews): all_fields_observed_in_scan; observed=rating; requires_join=False
- review_images (reviews): all_fields_observed_in_scan; observed=images; requires_join=False
- review_time (reviews): all_fields_observed_in_scan; observed=timestamp; requires_join=False
- user_item_interaction (reviews): all_fields_observed_in_scan; observed=user_id,asin,parent_asin,verified_purchase,helpful_vote; requires_join=False
- product_metadata (metadata): all_fields_observed_in_scan; observed=main_category,title,features,description,store,categories,details,bought_together,videos,average_rating,rating_number; requires_join=True
- product_images (metadata): all_fields_observed_in_scan; observed=images; requires_join=True
- product_price (metadata): all_fields_observed_in_scan; observed=price; requires_join=True

## Content availability by modality (S22)

Each denominator and operational definition is explicit; an image URL is not proof of a downloadable image.
Metadata values describe crawl-time pages, not necessarily historical review-time features.
Coverage in review_record_after_parent_join counts original review rows only; duplicate metadata rows do not inflate it.
For a repeated metadata parent, 'available' means SOME candidate row has content; unambiguous_available counts only reviews linked to exactly ONE metadata row.
Nonempty product-description containers must have at least one nonblank/finite scalar at any nesting depth; this is structural availability, not validated usefulness.
See modality_coverage.csv and modality_coverage in summary.json.

- review_text [review_record]: 701528/701528 (100.0%).
- review_rating [review_record]: 701528/701528 (100.0%).
- review_images [review_record]: 59684/701528 (8.507715%).
- review_time [review_record]: 701528/701528 (100.0%).
- user_item_interaction [review_record]: 701528/701528 (100.0%).
- review_text_body [review_record]: 700808/701528 (99.897367%).
- product_metadata [metadata_record]: 112590/112590 (100.0%).
- product_images [metadata_record]: 112590/112590 (100.0%).
- product_price [metadata_record]: 17704/112590 (15.724309%).
- product_metadata [review_record_after_parent_join]: 701528/701528 (100.0%); unambiguous=701528 (100.0%).
- product_images [review_record_after_parent_join]: 701528/701528 (100.0%); unambiguous=701528 (100.0%).
- product_price [review_record_after_parent_join]: 185623/701528 (26.459813%); unambiguous=185623 (26.459813%).

## Interpretation and limits

- This step inventories structure. It does not deduplicate, filter for 15 reviews, clean, build targets or split data.
- A JSONL file is a sequence of objects, not a fixed-width table. Field count means the union of observed top-level keys.
- A present null field is distinct from an absent field. A container is kept as a nested field, not flattened into invented rows.
- Identifier counts include all parseable object records with indexable IDs, irrespective of rating/time validity. Eligible-product counts belong to later work.
- ID indexing requires nonblank UTF-8-encodable strings; identifiers are not otherwise normalized.
- Relationship coverage from two independent head samples must not be generalized to the full dataset.
- Malformed, blank and non-object lines are structural diagnostics. Full quality quantification belongs to step 2.
- Current metadata aggregates and current product attributes are not introduced as historical model inputs.
- Runtime and SQLite versions, effective settings and content fingerprints are recorded in summary.json.
