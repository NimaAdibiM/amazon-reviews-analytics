# S23 — Comparison of information availability across Amazon categories

Each cell shows percent available (available / readable JSON-object review rows).
The category is the input-file label, not metadata.main_category.
Image availability means a nonblank URL descriptor, not confirmed image access.
Product image and price availability require a parent_asin metadata match.
Price refers to metadata at crawl time, not the historical review-time price.
Scan scope: entire_supplied_dataset_files. Head previews are NOT representative estimates.
Differences are descriptive only; S24 will examine association with category.

| Category | review text body | review text | review images | product images | product price |
|---|---:|---:|---:|---:|---:|
| Electronics | 99.91% | 100.00% | 4.61% | 99.99% | 58.30% |
| Beauty_and_Personal_Care | 99.85% | 100.00% | 7.10% | 100.00% | 70.03% |
| Appliances | 99.90% | 100.00% | 3.99% | 100.00% | 75.18% |
| All_Beauty | 99.90% | 100.00% | 8.51% | 100.00% | 26.46% |

See category_modality_comparison.csv for counts, missing percentages, metadata-record comparisons and exact denominators.
See category_modality_spread.csv for the descriptive gap in percentage points.
